
namespace Emby.Dlna
{
    public interface IContentDirectory : IEventManager, IUpnpService
    {
    }
}
