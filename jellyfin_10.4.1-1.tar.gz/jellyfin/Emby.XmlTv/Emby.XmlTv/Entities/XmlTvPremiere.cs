namespace Emby.XmlTv.Entities
{
    public class XmlTvPremiere
    {
        /*
        <premiere lang="en">
          First showing on national terrestrial TV
        </premiere>
        */

        public string Details { get; set; }
    }
}
