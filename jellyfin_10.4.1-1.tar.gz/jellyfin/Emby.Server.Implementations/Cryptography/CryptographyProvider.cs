using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using MediaBrowser.Model.Cryptography;
using static MediaBrowser.Common.Cryptography.Constants;

namespace Emby.Server.Implementations.Cryptography
{
    public class CryptographyProvider : ICryptoProvider, IDisposable
    {
        private static readonly HashSet<string> _supportedHashMethods = new HashSet<string>()
            {
                "MD5",
                "System.Security.Cryptography.MD5",
                "SHA",
                "SHA1",
                "System.Security.Cryptography.SHA1",
                "SHA256",
                "SHA-256",
                "System.Security.Cryptography.SHA256",
                "SHA384",
                "SHA-384",
                "System.Security.Cryptography.SHA384",
                "SHA512",
                "SHA-512",
                "System.Security.Cryptography.SHA512"
            };

        private RandomNumberGenerator _randomNumberGenerator;

        private bool _disposed = false;

        public CryptographyProvider()
        {
            // FIXME: When we get DotNet Standard 2.1 we need to revisit how we do the crypto
            // Currently supported hash methods from https://docs.microsoft.com/en-us/dotnet/api/system.security.cryptography.cryptoconfig?view=netcore-2.1
            // there might be a better way to autogenerate this list as dotnet updates, but I couldn't find one
            // Please note the default method of PBKDF2 is not included, it cannot be used to generate hashes cleanly as it is actually a pbkdf with sha1
            _randomNumberGenerator = RandomNumberGenerator.Create();
        }

        public string DefaultHashMethod => "PBKDF2";

        public IEnumerable<string> GetSupportedHashMethods()
            => _supportedHashMethods;

        private byte[] PBKDF2(string method, byte[] bytes, byte[] salt, int iterations)
        {
            // downgrading for now as we need this library to be dotnetstandard compliant
            // with this downgrade we'll add a check to make sure we're on the downgrade method at the moment
            if (method == DefaultHashMethod)
            {
                using (var r = new Rfc2898DeriveBytes(bytes, salt, iterations))
                {
                    return r.GetBytes(32);
                }
            }

            throw new CryptographicException($"Cannot currently use PBKDF2 with requested hash method: {method}");
        }

        public byte[] ComputeHash(string hashMethod, byte[] bytes)
            => ComputeHash(hashMethod, bytes, Array.Empty<byte>());

        public byte[] ComputeHashWithDefaultMethod(byte[] bytes)
            => ComputeHash(DefaultHashMethod, bytes);

        public byte[] ComputeHash(string hashMethod, byte[] bytes, byte[] salt)
        {
            if (hashMethod == DefaultHashMethod)
            {
                return PBKDF2(hashMethod, bytes, salt, DefaultIterations);
            }
            else if (_supportedHashMethods.Contains(hashMethod))
            {
                using (var h = HashAlgorithm.Create(hashMethod))
                {
                    if (salt.Length == 0)
                    {
                        return h.ComputeHash(bytes);
                    }
                    else
                    {
                        byte[] salted = new byte[bytes.Length + salt.Length];
                        Array.Copy(bytes, salted, bytes.Length);
                        Array.Copy(salt, 0, salted, bytes.Length, salt.Length);
                        return h.ComputeHash(salted);
                    }
                }
            }

            throw new CryptographicException($"Requested hash method is not supported: {hashMethod}");

        }

        public byte[] ComputeHashWithDefaultMethod(byte[] bytes, byte[] salt)
            => PBKDF2(DefaultHashMethod, bytes, salt, DefaultIterations);

        public byte[] GenerateSalt()
            => GenerateSalt(DefaultSaltLength);

        public byte[] GenerateSalt(int length)
        {
            byte[] salt = new byte[length];
            _randomNumberGenerator.GetBytes(salt);
            return salt;
        }

        /// <inheritdoc />
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                _randomNumberGenerator.Dispose();
            }

            _randomNumberGenerator = null;

            _disposed = true;
        }
    }
}
