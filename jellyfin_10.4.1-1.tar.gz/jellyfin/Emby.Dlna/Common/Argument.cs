
namespace Emby.Dlna.Common
{
    public class Argument
    {
        public string Name { get; set; }

        public string Direction { get; set; }

        public string RelatedStateVariable { get; set; }
    }
}
