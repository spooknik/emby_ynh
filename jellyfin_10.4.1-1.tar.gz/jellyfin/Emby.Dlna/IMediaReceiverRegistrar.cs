
namespace Emby.Dlna
{
    public interface IMediaReceiverRegistrar : IEventManager, IUpnpService
    {
    }
}
