
namespace Emby.Dlna
{
    public interface IConnectionManager : IEventManager, IUpnpService
    {
    }
}
