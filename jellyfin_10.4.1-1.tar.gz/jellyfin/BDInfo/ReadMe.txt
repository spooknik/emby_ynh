The source is taken from the BDRom folder of this project:

http://www.cinemasquid.com/blu-ray/tools/bdinfo

BDInfoSettings was taken from the FormSettings class, and changed so that the settings all return defaults.
