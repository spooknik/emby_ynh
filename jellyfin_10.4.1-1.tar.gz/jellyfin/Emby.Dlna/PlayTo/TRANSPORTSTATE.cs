namespace Emby.Dlna.PlayTo
{
    public enum TRANSPORTSTATE
    {
        STOPPED,
        PLAYING,
        TRANSITIONING,
        PAUSED_PLAYBACK,
        PAUSED
    }
}
